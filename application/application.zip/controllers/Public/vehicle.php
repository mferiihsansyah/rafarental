<?php

/**
 * @package			Codeigniter
 * @author      	Yulius
 * @license 		http://codeigniter.com/user_guide/license.html
 * @since 			Version 3.1.4
*/


// ------------------------------------------------------------------------

/**
 *	Application Controller Class Vehicle extends MY_Controller
 * 
 *	Class ini untuk halaman Kendaraan
 *
 *	@subpackage			model, view, helper, date
*/

defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicle extends MY_Controller {


	// Konstruktur
	function __construct()
	{
		parent::__construct();

		// mengambil data model, library, helper


		/**
		 *
		 * Model dan Helper di define dengan array
		 *
		*/

		$array_helper = array(
						'rpCurrency_helper',
						'exDate_helper',
						'webSetting_helper'
			);

		$array_model  = array(
						'admin/msetting',
						'public/pvehicle',
						'admin/mtype',
						'admin/mseat',
						'public/puser'
			);

		// MODEL
		$this->load->model($array_model);

		// HELPER
		$this->load->helper($array_helper);
	}

	// fungsi index
	public function index()
	{
		// var
		$var['title_web']		= 'Rafa Rental';
		$var['page_web']		= 'Kendaraan';

		// data
		$var['chat']			= $this->puser->load_chat();
		$var['menu'] 			= $this->msetting->load_menu();
		$var['bus_data'] 		= $this->pvehicle->load_data();
		$var['mobil']			= $this->pvehicle->load_mobil_order();
		$var['mobil_banyak'] 	= $this->pvehicle->load_mobil_banyak();

		// setting
		$var['bank_data']  		= $this->msetting->load_data_bank();
		$var['site_data']		= $this->msetting->load_data_ws();
		$var['type_car']		= $this->mtype->load_data();
		$var['seat_car']		= $this->mseat->load_data();
		if ($this->session->userdata('status')=="Login") 
		{
		// template
		$this->cs_template($var);
		$this->load->view('public/part/bus/index', $var);
		$this->load->view('public/template/end_content');
		$this->load->view('public/template/footerlogin');
		}else{
		// template
		$this->public_template($var);
		$this->load->view('public/part/bus/index', $var);
		$this->load->view('public/template/end_content');
		$this->load->view('public/template/footer');
		}

	}

	public function list()
	{
		// var
		$var['title_web']		= 'Rafa Rental';
		$var['page_web']		= 'Daftar Kendaraan';

		// data
		$var['chat']			= $this->puser->load_chat();
		$var['menu'] 			= $this->msetting->load_menu();
		$var['data'] 			= $this->pvehicle->load_data_mobil();
		$var['data_mobil']		= $this->pvehicle->load_data_slider();
		$var['mobil']			= $this->pvehicle->load_mobil_order();
		$var['mobil_banyak'] 	= $this->pvehicle->load_mobil_banyak();
		$var['recomend']		= $this->pvehicle->load_rekomendasi();

		// setting
		$var['bank_data']  		= $this->msetting->load_data_bank();
		$var['site_data']		= $this->msetting->load_data_ws();
		$var['type_car']		= $this->mtype->load_data();
		$var['seat_car']		= $this->mseat->load_data();
		if ($this->session->userdata('status')=="Login") 
		{
		// template
		$this->cs_template($var);
		$this->load->view('public/part/single/rent_bus', $var);
		$this->load->view('public/template/end_content');
		$this->load->view('public/template/footerlogin');
		}else{
		// template
		$this->public_template($var);
		$this->load->view('public/part/single/rent_bus', $var);
		$this->load->view('public/template/end_content');
		$this->load->view('public/template/footer');
		}

	}

	public function search_list($mirip)
	{
		// var
		$var['mirip']			= $mirip;
		$var['title_web']		= 'Rafa Rental';
		$var['page_web']		= 'Daftar Kendaraan';

		// data
		$var['chat']			= $this->puser->load_chat();
		$var['menu'] 			= $this->msetting->load_menu();
		$var['data'] 			= $this->pvehicle->search_data_mobil($mirip);
		$var['hitung'] 			= count($this->pvehicle->search_data_mobil($mirip));
		$var['data_mobil']		= $this->pvehicle->load_data_slider();
		$var['mobil']			= $this->pvehicle->load_mobil_order();
		$var['mobil_banyak'] 	= $this->pvehicle->load_mobil_banyak();
		$var['recomend']		= $this->pvehicle->load_rekomendasi();

		// setting
		$var['bank_data']  		= $this->msetting->load_data_bank();
		$var['site_data']		= $this->msetting->load_data_ws();
		$var['type_car']		= $this->mtype->load_data();
		$var['seat_car']		= $this->mseat->load_data();
		if ($this->session->userdata('status')=="Login") 
		{
		// template
		$this->cs_template($var);
		$this->load->view('public/part/single/search_bus', $var);
		$this->load->view('public/template/end_content');
		$this->load->view('public/template/footerlogin');
		}else{
		// template
		$this->public_template($var);
		$this->load->view('public/part/single/search_bus', $var);
		$this->load->view('public/template/end_content');
		$this->load->view('public/template/footer');
		}

	}

	// fungsi kendaraan / halaman
	public function single_page($id)
	{
		// var
		$var['chat']			= $this->puser->load_chat();
		$var['title_web']		= 'Rafa Rental';
		$var['page_web']		= $this->pvehicle->load_name($id);
		$var['menu'] 			= $this->msetting->load_menu();

		// data
		$var['bus_data']  		= $this->pvehicle->load_sc($id);

		// setting
		$var['bank_data']  		= $this->msetting->load_data_bank();
		$var['site_data']		= $this->msetting->load_data_ws();
		$var['type_car']		= $this->mtype->load_data();
		$var['seat_car']		= $this->mseat->load_data();

		// template
		if ($this->session->userdata('status')=="Login") 
		{
		// template
		$this->cs_template($var);
		$this->load->view('public/part/single/bus', $var);
		$this->load->view('public/template/footerlogin', $var);
		}else{
		// template
		$this->public_template($var);
		$this->load->view('public/part/single/bus', $var);
		$this->load->view('public/template/footer', $var);
		}

	}

	//fungsi sewa / halaman
	public function single_rent($id)
	{
		// var
		$var['chat']			= $this->puser->load_chat();
		$var['title_web']		= 'Rafa Rental';
		$var['page_web']		= $this->pvehicle->load_name($id);
		$var['menu'] 			= $this->msetting->load_menu();

		// data
		$var['bus_data']  		= $this->pvehicle->load_sc($id);

		// setting
		$var['bank_data']  		= $this->msetting->load_data_bank();
		$var['site_data']		= $this->msetting->load_data_ws();
		$var['type_car']		= $this->mtype->load_data();
		$var['seat_car']		= $this->mseat->load_data();

		// template
		if ($this->session->userdata('status')=="Login") 
		{
		// template
		$this->cs_template($var);
		$this->load->view('public/part/single/rent', $var);
		$this->load->view('public/template/footerlogin', $var);
		}else{
		$this->public_template($var);
		$this->load->view('public/part/single/rent', $var);
		$this->load->view('public/template/footer', $var);
		}
	}
	public function login()
	{
		$var['title_web']		= 'Rafa Rental';
		$var['page_web']		= 'Login';

		//template
		$this->load->view('public/part/bus/login');
	}

	public function waitlist($id)
	{
		// var
		$var['chat']			= $this->puser->load_chat();
		$var['title_web']		= 'Rafa Rental';
		$var['page_web']		= $this->pvehicle->load_name($id);
		$var['menu'] 			= $this->msetting->load_menu();

		// data
		$var['bus_data']  		= $this->pvehicle->load_sc($id);

		// setting
		$var['bank_data']  		= $this->msetting->load_data_bank();
		$var['site_data']		= $this->msetting->load_data_ws();
		$var['type_car']		= $this->mtype->load_data();
		$var['seat_car']		= $this->mseat->load_data();

		// template
		if ($this->session->userdata('status')=="Login") 
		{
		// template
		$this->cs_template($var);
		$this->load->view('public/part/single/waiting_list', $var);
		$this->load->view('public/template/footerlogin', $var);
		}else{
		$this->public_template($var);
		$this->load->view('public/part/single/waiting_list', $var);
		$this->load->view('public/template/footer', $var);
		}
	}
// end model
}